Tested with LINQPad 4.38.07 (Beta, free edition)

1. Build OxyPlot release
     Tools/build.cmd
2. Start LINQPad
3. Set the plugins/extensions and queries folders to the "OxyPlot/Source/Examples/LINQPad" folder
4. Test the "My extensions" main example
5. Test the SimpleFunction/SimpleLinePlot queries
