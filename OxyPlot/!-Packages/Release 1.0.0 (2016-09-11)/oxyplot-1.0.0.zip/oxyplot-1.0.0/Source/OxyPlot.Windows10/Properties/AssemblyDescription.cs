﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyDescription.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;
using System.Resources;

[assembly: AssemblyTitle("OxyPlot.Windows10")]
[assembly: AssemblyDescription("OxyPlot for Windows 10 Apps")]
[assembly: NeutralResourcesLanguage("en")]