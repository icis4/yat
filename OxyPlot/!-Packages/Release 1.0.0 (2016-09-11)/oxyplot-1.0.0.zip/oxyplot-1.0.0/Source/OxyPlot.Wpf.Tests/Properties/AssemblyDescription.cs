﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyDescription.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;

using NUnit.Framework;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("OxyPlot.Wpf.Tests")]
[assembly: AssemblyDescription("")]

// http://www.nunit.org/index.php?p=requiresSTA&r=2.5
[assembly: RequiresSTA]