﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NamespaceDoc.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// <summary>
//   The OxyPlot.Silverlight namespace contains controls for Silverlight.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace OxyPlot.Silverlight
{
    /// <summary>
    /// The OxyPlot.Silverlight namespace contains controls for Silverlight.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}