﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyDescription.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;
using System.Resources;

[assembly: AssemblyTitle("OxyPlot.Windows")]
[assembly: AssemblyDescription("OxyPlot for Windows Apps")]
[assembly: NeutralResourcesLanguage("en")]