﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyDescription.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Reflection;

[assembly: AssemblyTitle("OxyPlot for Windows Forms")]
[assembly: AssemblyDescription("OxyPlot controls for Windows Forms.")]

[assembly: CLSCompliant(true)]