﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExampleBrowser.Windows")]
[assembly: AssemblyDescription("Example Browser for Windows 8.1")]
