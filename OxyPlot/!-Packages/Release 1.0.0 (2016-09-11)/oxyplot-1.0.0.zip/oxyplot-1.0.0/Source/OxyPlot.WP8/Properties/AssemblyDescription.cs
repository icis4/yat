﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyDescription.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyTitle("OxyPlot.WP8")]
[assembly: AssemblyDescription("OxyPlot controls for Windows Phone Store apps")]