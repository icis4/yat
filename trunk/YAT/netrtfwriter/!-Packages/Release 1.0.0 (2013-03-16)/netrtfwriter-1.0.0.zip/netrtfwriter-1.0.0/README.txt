Please consult Debugger project for a tutorial of how to use this library, and RtfWriter project for details. 


Version 1.0.0 (03/16/2013)
*** Contributed by Matt Buckley and Thomson Reuters

* Support for sections and footers within sections.
* Support for style removals as well as additions.
* Support for different border/margin properties on each side.
* Support for different cell padding on each side.
* Made some methods public to enable unit testing.
* Changed storage of text to StringBuilder for speed.
* Support for alignment in paragraphs.
* Support for background colours in table cells.
* Upgraded to VS 2012.

