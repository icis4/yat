using System;
using ICSharpCode.USBlib;

namespace TerraD
{
	public class SISPMDriver : System.IDisposable
	{
		public static SISPMDriver Instance;
		
		static SISPMDriver()
		{
			Instance = new SISPMDriver();
		}
		
		const int VENDOR_ID  = 0x04B4;
		const int PRODUCT_ID = 0xFD11;
		
		const int SET_REQUESTTYPE = 0x21;
		const int GET_REQUESTTYPE = 0xA1;

		const int SET_REQUEST     = 0x09;
		const int GET_REQUEST     = 0x01;

		const int BUZZER_OUTLET   = 0x01;
		
		Device device;
		
		byte GetOutletNumber(int outlet)
		{
			switch (outlet) {
				case 0:
					return 3;
				case 1:
					return 6;
				case 2:
					return 9;
				case 3:
					return 0xC;
			}
			return 0;
		}
		
		void CheckInitialization()
		{
			if (!IsInitialized) {
				throw new SystemException();
			}
		}
		
		SISPMDriver()
		{
			foreach (Bus bus in Bus.Busses) {
				foreach (Descriptor descriptor in bus.Descriptors) {
					if (descriptor.VendorId  == VENDOR_ID &&
					    descriptor.ProductId == PRODUCT_ID) {
						device = descriptor.OpenDevice();
						return;
					}
				}
			}
		}
		
		public void Dispose()
		{
			if (device != null) {
				device.Dispose();
				device = null;
			}
		}
		
		~SISPMDriver()
		{
			Dispose();
		}
		
		public bool IsInitialized {
			get {
				return device != null;
			}
		}
		
		public void SetBuzzerStatus(bool buzzerOn) 
		{
			CheckInitialization();
			
			device.SendControlMessage(SET_REQUESTTYPE, 
			                          SET_REQUEST,
			                          (0x03 << 8) | BUZZER_OUTLET,
			                          new byte[] { 
			                          	BUZZER_OUTLET,
			                          	(byte)(buzzerOn ? 0x01 : 0x00)
			                          }
			                         );
		}
			
		public void SetSwitchStatus(int outlet, bool switchOn)
		{
			CheckInitialization();
			
			byte outletnr = GetOutletNumber(outlet);
				
			device.SendControlMessage(SET_REQUESTTYPE, 
			                          SET_REQUEST,
			                          (0x03 << 8) | outletnr,
			                          new byte[] { 
			                          	outletnr,
			                          	(byte)(switchOn ? 0x03 : 0x00)
			                          }
			                         );			
		}
		
		public bool GetSwitchStatus(int outlet)
		{
			CheckInitialization();
			
			byte outletnr = GetOutletNumber(outlet);
			byte[] buffer = new byte[] {
				outletnr,
				0x03
			};
			device.SendControlMessage(GET_REQUESTTYPE, 
			                          GET_REQUEST,
			                          (0x03 << 8) | outletnr,
			                          buffer
			                         );			
			return buffer[1] != 0;
		}
	}
}
