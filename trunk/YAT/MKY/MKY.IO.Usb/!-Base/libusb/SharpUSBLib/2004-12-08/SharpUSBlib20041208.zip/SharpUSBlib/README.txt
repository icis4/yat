#USBlib
----

#USBlib is a .NET wrapper around the libusb usb interface library. You need to have a working libusb on your system.

You can get libusb for unix here: http://libusb.sourceforge.net/
the win32 here: http://libusb-win32.sourceforge.net/

Note that for a working win32 version an installation of the libusb driver IS required.

License
-------
See COPYING_GPL.txt and COPYING_LGPL.txt. #USBlib is dual licensed. You can choose either GPL or LGPL.

(c) 2004 Mike Krueger 
