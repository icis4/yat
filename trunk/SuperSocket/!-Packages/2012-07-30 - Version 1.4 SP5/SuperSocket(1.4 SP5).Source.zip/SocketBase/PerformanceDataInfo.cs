﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperSocket.SocketBase
{
    public class PerformanceDataInfo
    {
        public string ServerName { get; set; }

        public PerformanceData Data { get; set; }
    }
}
