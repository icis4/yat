The source code of SuperWebSocket has been moved to a new separated open source project.
The project's homepage is http://superwebsocket.codeplex.com/