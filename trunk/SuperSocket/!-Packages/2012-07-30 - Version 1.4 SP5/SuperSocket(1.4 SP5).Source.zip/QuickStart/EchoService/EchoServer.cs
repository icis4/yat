﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SuperSocket.SocketBase;

namespace SuperSocket.QuickStart.EchoService
{
    public class EchoServer : AppServer<EchoSession>
    {

    }
}
