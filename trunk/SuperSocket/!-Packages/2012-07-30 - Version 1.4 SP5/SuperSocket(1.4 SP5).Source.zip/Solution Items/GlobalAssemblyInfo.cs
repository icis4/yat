﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.4.5.0")]
[assembly: AssemblyFileVersion("1.4.5.0")]
[assembly: AssemblyCompany("SuperSocket")]
[assembly: AssemblyProduct("SuperSocket")]
[assembly: AssemblyInformationalVersion("1.4.5.0")]
[assembly: AssemblyCopyright("Copyright © supersocket.codeplex.com 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]