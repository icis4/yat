﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using SuperSocket.SocketBase.Command;
using SuperSocket.SocketBase;

namespace SuperSocket.Facility.PolicyServer
{
    public class PolicySession : AppSession<PolicySession, BinaryCommandInfo>
    {

    }
}
