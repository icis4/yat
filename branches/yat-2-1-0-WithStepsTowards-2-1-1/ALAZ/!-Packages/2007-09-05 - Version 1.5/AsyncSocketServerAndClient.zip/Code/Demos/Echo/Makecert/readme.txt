Examples of creating the CA (Certificate Authority) and a certificate signed by this CA.
Source: http://blogs.technet.com/jhoward/archive/2005/02/02/365323.aspx

